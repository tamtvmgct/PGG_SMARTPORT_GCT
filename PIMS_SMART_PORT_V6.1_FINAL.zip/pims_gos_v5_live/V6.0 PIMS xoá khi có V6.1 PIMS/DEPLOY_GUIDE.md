# HƯỚNG DẪN TRIỂN KHAI HỆ THỐNG PIMS V6.1 (FINAL)

Chào mừng bạn đến với hệ thống Cảng thông minh (Smart Port Registration & Yard Management). Dưới đây là hướng dẫn để đưa hệ thống này hoạt động trên máy tính cá nhân hoặc server Internet.

## 1. Yêu cầu hệ thống
- **Node.js**: Phiên bản 16.x trở lên.
- **Trình duyệt**: Chrome, Edge hoặc Safari bản mới nhất (để hỗ trợ các tính năng AI & Excel).

## 2. Cài đặt trên máy tính cá nhân (Local)
1. Giải nén file `PIMS_SMART_PORT_V6.1_FINAL.zip`.
2. Mở cửa sổ Terminal (hoặc CMD) tại thư mục `pgg-server`.
3. Chạy lệnh: `npm install` (để cài đặt các thư viện cần thiết).
4. Chạy lệnh: `npm start` (hoặc `node server.js`).
5. Truy cập hệ thống tại:
   - Dashboard: `http://localhost:3000/index.html`
   - Cổng (GXT): `http://localhost:3000/gxt.html`
   - Bãi (GNT): `http://localhost:3000/gnt.html`

## 3. Triển khai lên Internet (Miễn phí 24/7 với Render.com)

Đây là cách để bạn có thể truy cập hệ thống từ bất kỳ đâu qua internet.

### Bước 1: Chuẩn bị Github
- Tạo một tài khoản trên [Github.com](https://github.com).
- Tạo một Repository mới (vd: `pims-v6`).
- Upload toàn bộ mã nguồn này (trừ thư mục `node_modules`) lên đó.

### Bước 2: Kết nối với Render.com
1. Đăng ký tài khoản tại [Render.com](https://render.com) (dùng tài khoản Github để đăng ký).
2. Chọn **"New +"** -> **"Web Service"**.
3. Kết nối với Repository `pims-v6` bạn vừa tạo trên Github.
4. Cấu hình các thông số sau:
   - **Name**: `pims-port-dongnai` (tên dự án của bạn).
   - **Environment**: `Node`.
   - **Build Command**: `cd pgg-server && npm install`.
   - **Start Command**: `cd pgg-server && node server.js`.
   - **Instance Type**: `Free`.
5. Bấm **"Create Web Service"**.

### Bước 3: Cập nhật URL (Rất quan trọng)
Sau khi Render cấp cho bạn một đường dẫn (ví dụ: `https://pims-port-dongnai.onrender.com`), bạn cần mở file `index.html`, `gxt.html` và `gnt.html` để sửa:
- `const API_BASE = "http://localhost:3000/api"` -> thành -> `"https://pims-port-dongnai.onrender.com/api"`.
- `const WS_URL = "ws://localhost:3000"` -> thành -> `"wss://pims-port-dongnai.onrender.com"`.

## 4. Tài khoản mặc định (Default Accounts)
- **Quản trị (Admin):** `admin` / `admin123`
- **Nhân viên Cổng (GXT):** `gxt` / `gxt123`
- **Nhân viên Bãi (GNT):** `gnt` / `gnt123`

---
*Bản quyền hệ thống thuộc về PIMS V6.1 - Port Integrated Management System.*
